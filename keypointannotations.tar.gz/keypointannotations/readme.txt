This repository contains the annotations with keypoints for a subset of the UFPR ADMR dataset (https://ieeexplore.ieee.org/abstract/document/9207318). The UFPR-ADMR is a public upon request dataset containing real multi-dial meters. These annotations were developed as part of my graduation thesis.

The annotations for each digit are the coordinates (in pixels) of the center of the digit, point of the dial, and the mark "zero" on the scale.

The annotations were made for the FIRST version of the UFPR-ADMR dataset, therefore the name of the files correspond to the files in the UFPR-ADMR dataset. You can safely concatenate these files into the corresponding files in this dataset.
